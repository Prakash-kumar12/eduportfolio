// ─────────────────────────────────────────────
//  Admin Routes (ADMIN role only)
//  GET    /api/admin/users           — list all users
//  GET    /api/admin/users/:id       — get one user + portfolio
//  PUT    /api/admin/users/:id       — edit user
//  POST   /api/admin/users/:id/suspend
//  POST   /api/admin/users/:id/restore
//  DELETE /api/admin/users/:id       — delete user
//  POST   /api/admin/users/:id/resend-otp
//  POST   /api/admin/users/:id/verify — manual verify
//  GET    /api/admin/stats           — dashboard stats
// ─────────────────────────────────────────────

const express = require('express');
const bcrypt  = require('bcryptjs');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { authenticate } = require('../middleware/auth');
const { asyncHandler }  = require('../utils/asyncHandler');
const { sendVerificationEmail } = require('../emails/mailer');
const { addMinutes } = require('../utils/time');

const router = express.Router();
router.use(authenticate);

// ── ADMIN GUARD ───────────────────────────────
async function requireAdmin(req, res, next) {
  const user = await prisma.user.findUnique({
    where: { id: req.userId },
    select: { role: true },
  });
  if (!user || user.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  next();
}
router.use(requireAdmin);

// ── STATS ─────────────────────────────────────
router.get('/stats', asyncHandler(async (req, res) => {
  const [total, verified, suspended] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { isEmailVerified: true } }),
    prisma.user.count({ where: { isSuspended: true } }),
  ]);
  const pending = total - verified;
  res.json({ total, verified, pending, suspended });
}));

// ── LIST ALL USERS ────────────────────────────
router.get('/users', asyncHandler(async (req, res) => {
  const { status, search, page = 1, limit = 50 } = req.query;
  const skip = (parseInt(page) - 1) * parseInt(limit);

  const where = {};
  if (status === 'verified')  { where.isEmailVerified = true;  where.isSuspended = false; }
  if (status === 'pending')   { where.isEmailVerified = false; where.isSuspended = false; }
  if (status === 'suspended') { where.isSuspended = true; }
  if (search) {
    where.OR = [
      { name:  { contains: search, mode: 'insensitive' } },
      { email: { contains: search, mode: 'insensitive' } },
    ];
  }

  const [users, total] = await Promise.all([
    prisma.user.findMany({
      where,
      skip,
      take: parseInt(limit),
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, name: true, email: true, role: true,
        isEmailVerified: true, isSuspended: true,
        createdAt: true, lastLoginAt: true,
        portfolio: { select: { school: true, subject: true, gradeLevel: true } },
      },
    }),
    prisma.user.count({ where }),
  ]);

  res.json({ users, total, page: parseInt(page), pages: Math.ceil(total / parseInt(limit)) });
}));

// ── GET ONE USER ──────────────────────────────
router.get('/users/:id', asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.params.id },
    select: {
      id: true, name: true, email: true, role: true,
      isEmailVerified: true, isSuspended: true,
      createdAt: true, lastLoginAt: true,
      portfolio: {
        include: {
          goals: true, pdLogs: true, artifacts: true,
          reflections: true, skills: true,
        },
      },
    },
  });
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json({ user });
}));

// ── EDIT USER ─────────────────────────────────
router.put('/users/:id', asyncHandler(async (req, res) => {
  const { name, email, role, password, school, subject, gradeLevel } = req.body;

  const updateData = {};
  if (name)  updateData.name  = name;
  if (email) updateData.email = email;
  if (role && ['EDUCATOR','ADMIN'].includes(role)) updateData.role = role;
  if (password && password.length >= 8) {
    updateData.passwordHash = await bcrypt.hash(password, 12);
  }

  const user = await prisma.user.update({
    where: { id: req.params.id },
    data:  updateData,
    select: { id: true, name: true, email: true, role: true },
  });

  // Update portfolio fields if provided
  if (school || subject || gradeLevel) {
    await prisma.portfolio.updateMany({
      where: { userId: req.params.id },
      data: {
        ...(school     && { school }),
        ...(subject    && { subject }),
        ...(gradeLevel && { gradeLevel }),
      },
    });
  }

  res.json({ user, message: 'User updated successfully.' });
}));

// ── SUSPEND ───────────────────────────────────
router.post('/users/:id/suspend', asyncHandler(async (req, res) => {
  await prisma.user.update({
    where: { id: req.params.id },
    data:  { isSuspended: true },
  });
  // Revoke all refresh tokens
  await prisma.refreshToken.deleteMany({ where: { userId: req.params.id } });
  res.json({ message: 'User suspended and sessions revoked.' });
}));

// ── RESTORE ───────────────────────────────────
router.post('/users/:id/restore', asyncHandler(async (req, res) => {
  await prisma.user.update({
    where: { id: req.params.id },
    data:  { isSuspended: false },
  });
  res.json({ message: 'User restored successfully.' });
}));

// ── DELETE ────────────────────────────────────
router.delete('/users/:id', asyncHandler(async (req, res) => {
  // Prevent deleting yourself
  if (req.params.id === req.userId) {
    return res.status(400).json({ error: 'You cannot delete your own admin account.' });
  }
  await prisma.user.delete({ where: { id: req.params.id } });
  res.json({ message: 'User and all their data deleted.' });
}));

// ── RESEND OTP ────────────────────────────────
router.post('/users/:id/resend-otp', asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.params.id } });
  if (!user) return res.status(404).json({ error: 'User not found.' });
  if (user.isEmailVerified) return res.status(400).json({ error: 'User is already verified.' });

  const otp    = Math.floor(100000 + Math.random() * 900000).toString();
  const expiry = addMinutes(new Date(), 60);

  await prisma.user.update({
    where: { id: user.id },
    data:  { emailVerifyToken: otp, emailVerifyExpiry: expiry },
  });

  await sendVerificationEmail({ to: user.email, name: user.name, otp });

  res.json({ message: `Verification OTP resent to ${user.email}` });
}));

// ── MANUAL VERIFY ─────────────────────────────
router.post('/users/:id/verify', asyncHandler(async (req, res) => {
  await prisma.user.update({
    where: { id: req.params.id },
    data:  { isEmailVerified: true, emailVerifyToken: null, emailVerifyExpiry: null },
  });
  res.json({ message: 'User manually verified.' });
}));

module.exports = router;
