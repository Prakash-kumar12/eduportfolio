// ─────────────────────────────────────────────
//  Auth Routes
//  POST /api/auth/register
//  POST /api/auth/login
//  POST /api/auth/verify-email
//  POST /api/auth/resend-verification
//  POST /api/auth/refresh-token
//  POST /api/auth/logout
//  POST /api/auth/forgot-password
//  POST /api/auth/reset-password
//  GET  /api/auth/me
// ─────────────────────────────────────────────

const express      = require('express');
const bcrypt       = require('bcryptjs');
const jwt          = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const Joi          = require('joi');
const rateLimit    = require('express-rate-limit');

const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const { sendVerificationEmail, sendPasswordResetEmail } = require('../emails/mailer');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../utils/asyncHandler');
const { addMinutes, isAfter } = require('../utils/time');

const router = express.Router();

// ── RATE LIMITERS ──────────────────────────────
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  message: { error: 'Too many attempts. Please try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const resendLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 2,
  message: { error: 'Please wait before requesting another code.' },
});

// ── VALIDATION SCHEMAS ─────────────────────────
const registerSchema = Joi.object({
  name:     Joi.string().min(2).max(100).required(),
  email:    Joi.string().email().required(),
  password: Joi.string().min(8).max(128).required(),
});

const loginSchema = Joi.object({
  email:    Joi.string().email().required(),
  password: Joi.string().required(),
});

const emailSchema = Joi.object({
  email: Joi.string().email().required(),
});

const resetSchema = Joi.object({
  token:    Joi.string().required(),
  password: Joi.string().min(8).max(128).required(),
});

// ── HELPERS ───────────────────────────────────
function generateOtp() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function generateTokens(userId) {
  const access = jwt.sign(
    { sub: userId },
    process.env.JWT_ACCESS_SECRET,
    { expiresIn: process.env.JWT_ACCESS_EXPIRES || '15m' }
  );
  const refresh = jwt.sign(
    { sub: userId },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES || '7d' }
  );
  return { access, refresh };
}

// ── REGISTER ──────────────────────────────────
router.post('/register', authLimiter, asyncHandler(async (req, res) => {
  const { error, value } = registerSchema.validate(req.body);
  if (error) return res.status(400).json({ error: error.details[0].message });

  const { name, email, password } = value;

  // Check if user already exists
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    // Generic message to prevent user enumeration
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }

  const passwordHash = await bcrypt.hash(password, 12);

  // Generate 6-digit OTP for email verification
  const otp    = generateOtp();
  const expiry = addMinutes(new Date(), parseInt(process.env.EMAIL_VERIFY_EXPIRY_MINS) || 60);

  const user = await prisma.user.create({
    data: {
      name,
      email,
      passwordHash,
      emailVerifyToken: otp,
      emailVerifyExpiry: expiry,
      portfolio: { create: {} }, // auto-create empty portfolio
    },
    select: { id: true, name: true, email: true },
  });

  await sendVerificationEmail({ to: email, name, otp });

  res.status(201).json({
    message: 'Account created. Check your email for a 6-digit verification code.',
    userId: user.id,
  });
}));

// ── VERIFY EMAIL ──────────────────────────────
router.post('/verify-email', authLimiter, asyncHandler(async (req, res) => {
  const { email, code } = req.body;

  if (!email || !code) {
    return res.status(400).json({ error: 'Email and verification code are required.' });
  }

  const user = await prisma.user.findUnique({ where: { email } });

  if (!user || user.emailVerifyToken !== code) {
    return res.status(400).json({ error: 'Invalid verification code.' });
  }

  if (isAfter(new Date(), user.emailVerifyExpiry)) {
    return res.status(400).json({ error: 'Code has expired. Please request a new one.' });
  }

  await prisma.user.update({
    where: { id: user.id },
    data: {
      isEmailVerified:  true,
      emailVerifyToken: null,
      emailVerifyExpiry: null,
    },
  });

  // Issue tokens after verification
  const { access, refresh } = generateTokens(user.id);

  await prisma.refreshToken.create({
    data: {
      token: refresh,
      userId: user.id,
      expiresAt: addMinutes(new Date(), 60 * 24 * 7), // 7 days
    },
  });

  res.json({
    message: 'Email verified successfully.',
    accessToken: access,
    refreshToken: refresh,
    user: { id: user.id, name: user.name, email: user.email },
  });
}));

// ── RESEND VERIFICATION ───────────────────────
router.post('/resend-verification', resendLimiter, asyncHandler(async (req, res) => {
  const { error, value } = emailSchema.validate(req.body);
  if (error) return res.status(400).json({ error: error.details[0].message });

  const user = await prisma.user.findUnique({ where: { email: value.email } });

  // Always return 200 to prevent user enumeration
  if (!user || user.isEmailVerified) {
    return res.json({ message: 'If this email exists and is unverified, a new code has been sent.' });
  }

  const otp    = generateOtp();
  const expiry = addMinutes(new Date(), parseInt(process.env.EMAIL_VERIFY_EXPIRY_MINS) || 60);

  await prisma.user.update({
    where: { id: user.id },
    data: { emailVerifyToken: otp, emailVerifyExpiry: expiry },
  });

  await sendVerificationEmail({ to: user.email, name: user.name, otp });

  res.json({ message: 'If this email exists and is unverified, a new code has been sent.' });
}));

// ── LOGIN ─────────────────────────────────────
router.post('/login', authLimiter, asyncHandler(async (req, res) => {
  const { error, value } = loginSchema.validate(req.body);
  if (error) return res.status(400).json({ error: error.details[0].message });

  const { email, password } = value;

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  if (!user.isEmailVerified) {
    return res.status(403).json({
      error: 'Please verify your email before signing in.',
      requiresVerification: true,
    });
  }

  const { access, refresh } = generateTokens(user.id);

  await prisma.refreshToken.create({
    data: {
      token: refresh,
      userId: user.id,
      expiresAt: addMinutes(new Date(), 60 * 24 * 7),
    },
  });

  await prisma.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() },
  });

  res.json({
    accessToken: access,
    refreshToken: refresh,
    user: {
      id:    user.id,
      name:  user.name,
      email: user.email,
      role:  user.role,
    },
  });
}));

// ── REFRESH TOKEN ─────────────────────────────
router.post('/refresh-token', asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'Refresh token required.' });

  let payload;
  try {
    payload = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
  } catch {
    return res.status(401).json({ error: 'Invalid or expired refresh token.' });
  }

  const stored = await prisma.refreshToken.findUnique({ where: { token: refreshToken } });
  if (!stored || isAfter(new Date(), stored.expiresAt)) {
    return res.status(401).json({ error: 'Refresh token is no longer valid.' });
  }

  // Rotate: delete old, issue new
  await prisma.refreshToken.delete({ where: { id: stored.id } });

  const { access, refresh } = generateTokens(payload.sub);

  await prisma.refreshToken.create({
    data: {
      token: refresh,
      userId: payload.sub,
      expiresAt: addMinutes(new Date(), 60 * 24 * 7),
    },
  });

  res.json({ accessToken: access, refreshToken: refresh });
}));

// ── LOGOUT ────────────────────────────────────
router.post('/logout', asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) {
    await prisma.refreshToken.deleteMany({ where: { token: refreshToken } });
  }
  res.json({ message: 'Logged out successfully.' });
}));

// ── FORGOT PASSWORD ───────────────────────────
router.post('/forgot-password', authLimiter, asyncHandler(async (req, res) => {
  const { error, value } = emailSchema.validate(req.body);
  if (error) return res.status(400).json({ error: error.details[0].message });

  const user = await prisma.user.findUnique({ where: { email: value.email } });

  // Always 200 — don't leak whether email exists
  if (!user) {
    return res.json({ message: 'If this email is registered, a reset link has been sent.' });
  }

  const token  = uuid();
  const expiry = addMinutes(new Date(), parseInt(process.env.RESET_TOKEN_EXPIRY_MINS) || 30);

  await prisma.user.update({
    where: { id: user.id },
    data: { resetToken: token, resetTokenExpiry: expiry },
  });

  await sendPasswordResetEmail({ to: user.email, name: user.name, token });

  res.json({ message: 'If this email is registered, a reset link has been sent.' });
}));

// ── RESET PASSWORD ────────────────────────────
router.post('/reset-password', authLimiter, asyncHandler(async (req, res) => {
  const { error, value } = resetSchema.validate(req.body);
  if (error) return res.status(400).json({ error: error.details[0].message });

  const { token, password } = value;

  const user = await prisma.user.findUnique({ where: { resetToken: token } });
  if (!user) return res.status(400).json({ error: 'Invalid or expired reset token.' });

  if (isAfter(new Date(), user.resetTokenExpiry)) {
    return res.status(400).json({ error: 'Reset token has expired. Please request a new one.' });
  }

  const passwordHash = await bcrypt.hash(password, 12);

  await prisma.user.update({
    where: { id: user.id },
    data: {
      passwordHash,
      resetToken: null,
      resetTokenExpiry: null,
    },
  });

  // Invalidate all refresh tokens on password reset
  await prisma.refreshToken.deleteMany({ where: { userId: user.id } });

  res.json({ message: 'Password reset successfully. Please sign in with your new password.' });
}));

// ── GET CURRENT USER ──────────────────────────
router.get('/me', authenticate, asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.userId },
    select: {
      id: true, name: true, email: true, role: true,
      isEmailVerified: true, createdAt: true, lastLoginAt: true,
    },
  });
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json({ user });
}));

module.exports = router;
