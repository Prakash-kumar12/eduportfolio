// ─────────────────────────────────────────────
//  Portfolio Routes (all protected)
//  GET    /api/portfolio
//  PUT    /api/portfolio
//  POST   /api/portfolio/goals
//  PUT    /api/portfolio/goals/:id
//  DELETE /api/portfolio/goals/:id
//  POST   /api/portfolio/pd
//  PUT    /api/portfolio/pd/:id
//  DELETE /api/portfolio/pd/:id
//  POST   /api/portfolio/artifacts
//  PUT    /api/portfolio/artifacts/:id
//  DELETE /api/portfolio/artifacts/:id
//  POST   /api/portfolio/reflections
//  PUT    /api/portfolio/skills
// ─────────────────────────────────────────────

const express = require('express');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../utils/asyncHandler');

const router = express.Router();
router.use(authenticate); // All portfolio routes require auth

// Helper: get portfolio ID for current user
async function getPortfolioId(userId) {
  const p = await prisma.portfolio.findUnique({ where: { userId }, select: { id: true } });
  if (!p) throw Object.assign(new Error('Portfolio not found'), { status: 404 });
  return p.id;
}

// ── GET FULL PORTFOLIO ─────────────────────────
router.get('/', asyncHandler(async (req, res) => {
  const portfolio = await prisma.portfolio.findUnique({
    where: { userId: req.userId },
    include: {
      goals:       { orderBy: { createdAt: 'asc' } },
      pdLogs:      { orderBy: { date: 'desc' } },
      artifacts:   { orderBy: { createdAt: 'desc' } },
      reflections: { orderBy: { createdAt: 'desc' } },
      skills:      true,
    },
  });
  if (!portfolio) return res.status(404).json({ error: 'Portfolio not found.' });
  res.json({ portfolio });
}));

// ── UPDATE PORTFOLIO PROFILE ───────────────────
router.put('/', asyncHandler(async (req, res) => {
  const { bio, teachingPhilo, school, subject, gradeLevel, yearsTeaching, focusGoal, avatarUrl } = req.body;
  const portfolio = await prisma.portfolio.update({
    where: { userId: req.userId },
    data: { bio, teachingPhilo, school, subject, gradeLevel, yearsTeaching, focusGoal, avatarUrl },
  });
  res.json({ portfolio });
}));

// ── GOALS ──────────────────────────────────────
router.post('/goals', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  const { title, description, status, targetDate } = req.body;
  if (!title) return res.status(400).json({ error: 'Goal title is required.' });

  const goal = await prisma.goal.create({
    data: { portfolioId, title, description, status, targetDate: targetDate ? new Date(targetDate) : null },
  });
  res.status(201).json({ goal });
}));

router.put('/goals/:id', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  const { title, description, status, targetDate } = req.body;

  const goal = await prisma.goal.updateMany({
    where: { id: req.params.id, portfolioId },
    data: { title, description, status, targetDate: targetDate ? new Date(targetDate) : undefined,
            completedAt: status === 'COMPLETED' ? new Date() : undefined },
  });
  res.json({ updated: goal.count > 0 });
}));

router.delete('/goals/:id', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  await prisma.goal.deleteMany({ where: { id: req.params.id, portfolioId } });
  res.json({ deleted: true });
}));

// ── PD LOG ─────────────────────────────────────
router.post('/pd', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  const { title, type, provider, hours, date, description, reflection, certUrl } = req.body;
  if (!title) return res.status(400).json({ error: 'PD title is required.' });

  const log = await prisma.pdLog.create({
    data: { portfolioId, title, type, provider, hours, date: date ? new Date(date) : null,
            description, reflection, certUrl },
  });
  res.status(201).json({ log });
}));

router.put('/pd/:id', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  const { title, type, provider, hours, date, description, reflection, certUrl } = req.body;
  const updated = await prisma.pdLog.updateMany({
    where: { id: req.params.id, portfolioId },
    data: { title, type, provider, hours, date: date ? new Date(date) : undefined,
            description, reflection, certUrl },
  });
  res.json({ updated: updated.count > 0 });
}));

router.delete('/pd/:id', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  await prisma.pdLog.deleteMany({ where: { id: req.params.id, portfolioId } });
  res.json({ deleted: true });
}));

// ── ARTIFACTS ──────────────────────────────────
router.post('/artifacts', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  const { title, type, description, fileUrl, tags, isPublic } = req.body;
  if (!title) return res.status(400).json({ error: 'Artifact title is required.' });

  const artifact = await prisma.artifact.create({
    data: { portfolioId, title, type, description, fileUrl, tags: tags || [], isPublic: !!isPublic },
  });
  res.status(201).json({ artifact });
}));

router.put('/artifacts/:id', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  const { title, type, description, fileUrl, tags, isPublic } = req.body;
  const updated = await prisma.artifact.updateMany({
    where: { id: req.params.id, portfolioId },
    data: { title, type, description, fileUrl, tags, isPublic },
  });
  res.json({ updated: updated.count > 0 });
}));

router.delete('/artifacts/:id', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  await prisma.artifact.deleteMany({ where: { id: req.params.id, portfolioId } });
  res.json({ deleted: true });
}));

// ── REFLECTIONS ────────────────────────────────
router.post('/reflections', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  const { title, content, period } = req.body;
  if (!content) return res.status(400).json({ error: 'Reflection content is required.' });

  const reflection = await prisma.reflection.create({
    data: { portfolioId, title, content, period },
  });
  res.status(201).json({ reflection });
}));

// ── SKILLS ─────────────────────────────────────
// PUT replaces all skills for this portfolio
router.put('/skills', asyncHandler(async (req, res) => {
  const portfolioId = await getPortfolioId(req.userId);
  const { skills } = req.body; // [{ name, isActive }]
  if (!Array.isArray(skills)) return res.status(400).json({ error: 'skills must be an array.' });

  // Delete existing, re-create
  await prisma.portfolioSkill.deleteMany({ where: { portfolioId } });
  const created = await prisma.portfolioSkill.createMany({
    data: skills.map(s => ({ portfolioId, name: s.name, isActive: !!s.isActive })),
    skipDuplicates: true,
  });
  res.json({ created: created.count });
}));

module.exports = router;
