// Global error handler
function errorHandler(err, req, res, next) {
  console.error(`[ERROR] ${err.message}`, err.stack);
  const status = err.status || 500;
  res.status(status).json({
    error: status === 500 ? 'An internal server error occurred.' : err.message,
  });
}

module.exports = { errorHandler };
