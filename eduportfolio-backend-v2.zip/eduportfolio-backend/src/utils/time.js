function addMinutes(date, minutes) {
  return new Date(date.getTime() + minutes * 60 * 1000);
}

function isAfter(date, compareDate) {
  return date.getTime() > compareDate.getTime();
}

module.exports = { addMinutes, isAfter };
