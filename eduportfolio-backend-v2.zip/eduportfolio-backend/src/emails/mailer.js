// ─────────────────────────────────────────────
//  EduPortfolio — Email Mailer (Nodemailer)
// ─────────────────────────────────────────────
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host:   process.env.SMTP_HOST,
  port:   parseInt(process.env.SMTP_PORT) || 587,
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// ── SHARED HTML WRAPPER ──
function htmlWrapper(content) {
  return `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <style>
      body { font-family: Georgia, serif; background: #f5f0e8; margin: 0; padding: 40px 20px; }
      .card { background: #ffffff; border-radius: 16px; max-width: 520px; margin: 0 auto; padding: 48px; border: 1px solid #e8e0d4; }
      .brand { font-family: Georgia, serif; font-style: italic; font-size: 1.1rem; color: #6fcf97; margin-bottom: 32px; }
      h1 { font-family: Georgia, serif; font-size: 1.8rem; color: #1a1a2e; margin-bottom: 16px; font-weight: 400; }
      p { color: #666; line-height: 1.8; font-size: 0.95rem; margin-bottom: 16px; }
      .otp { font-family: 'Courier New', monospace; font-size: 2.5rem; letter-spacing: 0.3em; color: #1a1a2e; background: #f0f9f4; border: 2px solid #6fcf97; border-radius: 12px; padding: 20px 32px; text-align: center; margin: 28px 0; font-weight: bold; }
      .btn { display: inline-block; background: #6fcf97; color: #0d0f14; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-family: Georgia, serif; font-size: 1rem; font-weight: bold; margin: 20px 0; }
      .note { font-size: 0.78rem; color: #aaa; margin-top: 32px; padding-top: 20px; border-top: 1px solid #eee; }
      .footer { text-align: center; color: #bbb; font-size: 0.72rem; margin-top: 32px; font-family: monospace; letter-spacing: 0.06em; }
    </style>
  </head>
  <body>
    <div class="card">
      <div class="brand">✦ EduPortfolio</div>
      ${content}
    </div>
    <div class="footer">© 2026 EDUPORTFOLIO · THIS IS AN AUTOMATED MESSAGE</div>
  </body>
  </html>`;
}

// ── SEND VERIFICATION EMAIL ──
async function sendVerificationEmail({ to, name, otp }) {
  const html = htmlWrapper(`
    <h1>Verify your email</h1>
    <p>Hi ${name},</p>
    <p>Welcome to EduPortfolio! Enter the 6-digit code below to verify your email address and activate your account.</p>
    <div class="otp">${otp}</div>
    <p>This code expires in <strong>60 minutes</strong>.</p>
    <div class="note">If you didn't create an EduPortfolio account, you can safely ignore this email.</div>
  `);

  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to,
    subject: `${otp} is your EduPortfolio verification code`,
    text:    `Hi ${name},\n\nYour EduPortfolio verification code is: ${otp}\n\nThis code expires in 60 minutes.\n\nIf you didn't create an account, ignore this email.`,
    html,
  });
}

// ── SEND PASSWORD RESET EMAIL ──
async function sendPasswordResetEmail({ to, name, token }) {
  const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${token}`;

  const html = htmlWrapper(`
    <h1>Reset your password</h1>
    <p>Hi ${name},</p>
    <p>We received a request to reset the password for your EduPortfolio account.</p>
    <a class="btn" href="${resetUrl}">Reset Password →</a>
    <p>Or copy this link into your browser:</p>
    <p style="word-break:break-all;font-size:0.78rem;color:#aaa;">${resetUrl}</p>
    <div class="note">This link expires in <strong>30 minutes</strong>. If you didn't request a password reset, you can safely ignore this email — your password won't be changed.</div>
  `);

  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to,
    subject: 'Reset your EduPortfolio password',
    text:    `Hi ${name},\n\nReset your password here: ${resetUrl}\n\nThis link expires in 30 minutes.\n\nIf you didn't request this, ignore this email.`,
    html,
  });
}

module.exports = { sendVerificationEmail, sendPasswordResetEmail };
