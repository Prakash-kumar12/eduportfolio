// ─────────────────────────────────────────────
//  EduPortfolio — Database Seed
//  Run: npm run db:seed
// ─────────────────────────────────────────────
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  const passwordHash = await bcrypt.hash('Password123!', 12);

  const user = await prisma.user.upsert({
    where: { email: 'demo@eduportfolio.com' },
    update: {},
    create: {
      email: 'demo@eduportfolio.com',
      name: 'Demo Educator',
      passwordHash,
      isEmailVerified: true,
      portfolio: {
        create: {
          bio: 'A passionate educator with a love for inquiry-based learning.',
          school: 'Demo Academy',
          subject: 'Science',
          gradeLevel: 'Grade 9',
          yearsTeaching: 8,
          focusGoal: 'Differentiated Instruction',
          goals: {
            create: [
              { title: 'Implement daily exit tickets', status: 'IN_PROGRESS' },
              { title: 'Complete UDL certification', status: 'IN_PROGRESS' },
            ],
          },
          skills: {
            create: [
              { name: 'Inquiry-Based Learning', isActive: true },
              { name: 'Formative Assessment', isActive: true },
              { name: 'Project-Based Learning', isActive: false },
            ],
          },
        },
      },
    },
  });

  console.log(`✦ Seeded demo user: ${user.email}`);
  console.log('  Password: Password123!');
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
