# EduPortfolio Backend

A complete authentication + portfolio API for educators.  
**Stack**: Node.js · Express · PostgreSQL · Prisma ORM · JWT · Nodemailer

---

## Features

- ✅ Registration with email verification (6-digit OTP)
- ✅ Secure login with bcrypt password hashing
- ✅ JWT access tokens (15min) + refresh token rotation (7 days)
- ✅ Forgot/reset password via email link
- ✅ Rate limiting on all auth endpoints
- ✅ Full portfolio CRUD (goals, PD logs, artifacts, reflections, skills)
- ✅ PostgreSQL database via Prisma ORM
- ✅ HTML email templates

---

## Setup

### 1. Prerequisites

- Node.js 18+
- PostgreSQL 14+ running locally or on a hosted service (e.g. Supabase, Railway, Neon)

### 2. Install dependencies

```bash
npm install
```

### 3. Configure environment

```bash
cp .env.example .env
```

Edit `.env` and fill in:
- `DATABASE_URL` — your PostgreSQL connection string
- `JWT_ACCESS_SECRET` + `JWT_REFRESH_SECRET` — generate with:
  ```bash
  node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
  ```
- SMTP settings (Gmail, Mailgun, Resend, etc.)

### 4. Set up the database

```bash
# Run migrations
npm run db:migrate

# Generate Prisma client
npm run db:generate

# (Optional) Seed with demo data
npm run db:seed
```

### 5. Start the server

```bash
# Development (auto-restart)
npm run dev

# Production
npm start
```

Server starts at `http://localhost:4000`

---

## API Reference

### Auth Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/auth/register` | Create account | No |
| POST | `/api/auth/verify-email` | Verify OTP code | No |
| POST | `/api/auth/resend-verification` | Resend OTP | No |
| POST | `/api/auth/login` | Sign in | No |
| POST | `/api/auth/refresh-token` | Rotate tokens | No |
| POST | `/api/auth/logout` | Sign out | No |
| POST | `/api/auth/forgot-password` | Request reset email | No |
| POST | `/api/auth/reset-password` | Set new password | No |
| GET  | `/api/auth/me` | Get current user | ✅ Bearer |

### Portfolio Endpoints (all require Bearer token)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/portfolio` | Get full portfolio |
| PUT | `/api/portfolio` | Update profile |
| POST | `/api/portfolio/goals` | Add goal |
| PUT | `/api/portfolio/goals/:id` | Update goal |
| DELETE | `/api/portfolio/goals/:id` | Delete goal |
| POST | `/api/portfolio/pd` | Log PD activity |
| PUT | `/api/portfolio/pd/:id` | Update PD entry |
| DELETE | `/api/portfolio/pd/:id` | Delete PD entry |
| POST | `/api/portfolio/artifacts` | Add artifact |
| PUT | `/api/portfolio/artifacts/:id` | Update artifact |
| DELETE | `/api/portfolio/artifacts/:id` | Delete artifact |
| POST | `/api/portfolio/reflections` | Add reflection |
| PUT | `/api/portfolio/skills` | Replace all skills |

---

## Connecting the Frontend UI

In the `auth-ui.html` file, replace the `setTimeout` simulation blocks in each handler with real `fetch` calls:

```javascript
// Example: Register
const res = await fetch('http://localhost:4000/api/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ name, email, password }),
});
const data = await res.json();
if (!res.ok) { /* show error */ } else { /* show verify screen */ }

// Example: Login
const res = await fetch('http://localhost:4000/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password }),
});
const { accessToken, refreshToken, user } = await res.json();
localStorage.setItem('accessToken', accessToken);

// Example: Authenticated request
const res = await fetch('http://localhost:4000/api/portfolio', {
  headers: { Authorization: `Bearer ${localStorage.getItem('accessToken')}` },
});
```

---

## Email Setup Options

| Provider | Free Tier | Notes |
|----------|-----------|-------|
| **Gmail** | Yes | Use App Password (not account password) |
| **Resend** | 3,000/mo free | Best for production — `smtp.resend.com` |
| **Mailgun** | 1,000/mo free | Reliable, easy setup |
| **Mailtrap** | Yes | Dev/testing only, doesn't send real emails |

---

## Security Notes

- Passwords hashed with bcrypt (cost factor 12)
- Rate limiting: 10 requests/15min on auth routes
- JWT secrets should be 64+ random bytes
- Refresh tokens stored in DB and rotated on each use
- Password resets invalidate all existing refresh tokens
- Email enumeration prevention on forgot-password + resend
