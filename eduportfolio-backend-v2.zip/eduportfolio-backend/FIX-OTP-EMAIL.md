# ─────────────────────────────────────────────
#  FIX: OTP Emails Not Arriving
#  Two options — Gmail (free) or Resend (easiest)
# ─────────────────────────────────────────────

## WHY OTP IS NOT ARRIVING
The backend uses SMTP to send emails. If .env is not configured,
emails silently fail. Fix it with ONE of these two options:

═══════════════════════════════════════════════
  OPTION A: Gmail App Password (Free, 5 minutes)
═══════════════════════════════════════════════

Step 1 — Enable 2FA on your Google account:
  → myaccount.google.com → Security → 2-Step Verification → Turn ON

Step 2 — Create an App Password:
  → myaccount.google.com → Security → App Passwords
  → App: "Mail"  |  Device: "Other" → name it "EduPortfolio"
  → Google gives you a 16-character password like: abcd efgh ijkl mnop

Step 3 — Update your .env file:
  SMTP_HOST=smtp.gmail.com
  SMTP_PORT=587
  SMTP_SECURE=false
  SMTP_USER=your.gmail@gmail.com
  SMTP_PASS=abcdefghijklmnop        ← the 16-char app password (no spaces)
  EMAIL_FROM="EduPortfolio <your.gmail@gmail.com>"

Step 4 — Restart your server:
  npm run dev

Step 5 — Test it:
  Register a new account → OTP will arrive in inbox within 30 seconds.
  Check spam folder if not in inbox.


═══════════════════════════════════════════════
  OPTION B: Resend.com (Recommended for production)
═══════════════════════════════════════════════

Step 1 — Sign up free at https://resend.com
  → Free tier: 3,000 emails/month, 100/day

Step 2 — Get your API key:
  → Dashboard → API Keys → Create API Key → copy it

Step 3 — Install the Resend SDK:
  npm install resend

Step 4 — Replace src/emails/mailer.js with this:

─────────────────────────────────────────────
const { Resend } = require('resend');
const resend = new Resend(process.env.RESEND_API_KEY);

async function sendVerificationEmail({ to, name, otp }) {
  await resend.emails.send({
    from: process.env.EMAIL_FROM || 'EduPortfolio <onboarding@resend.dev>',
    to,
    subject: `${otp} is your EduPortfolio verification code`,
    html: `
      <div style="font-family:Georgia,serif;max-width:520px;margin:0 auto;padding:40px;background:#fff;border-radius:16px">
        <h2 style="color:#6fcf97">✦ EduPortfolio</h2>
        <h1 style="font-weight:400;color:#1a1a2e">Verify your email</h1>
        <p style="color:#666">Hi ${name}, your verification code is:</p>
        <div style="font-family:monospace;font-size:2.5rem;letter-spacing:0.3em;background:#f0f9f4;border:2px solid #6fcf97;border-radius:12px;padding:20px;text-align:center;color:#1a1a2e;margin:24px 0">${otp}</div>
        <p style="color:#999;font-size:0.85rem">This code expires in 60 minutes.</p>
      </div>`,
  });
}

async function sendPasswordResetEmail({ to, name, token }) {
  const url = \`\${process.env.FRONTEND_URL}/reset-password?token=\${token}\`;
  await resend.emails.send({
    from: process.env.EMAIL_FROM || 'EduPortfolio <onboarding@resend.dev>',
    to,
    subject: 'Reset your EduPortfolio password',
    html: \`
      <div style="font-family:Georgia,serif;max-width:520px;margin:0 auto;padding:40px;background:#fff;border-radius:16px">
        <h2 style="color:#6fcf97">✦ EduPortfolio</h2>
        <h1 style="font-weight:400;color:#1a1a2e">Reset your password</h1>
        <p style="color:#666">Hi \${name}, click below to reset your password:</p>
        <a href="\${url}" style="display:inline-block;background:#6fcf97;color:#0d0f14;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:bold;margin:20px 0">Reset Password →</a>
        <p style="color:#999;font-size:0.85rem">Link expires in 30 minutes.</p>
      </div>\`,
  });
}

module.exports = { sendVerificationEmail, sendPasswordResetEmail };
─────────────────────────────────────────────

Step 5 — Add to .env:
  RESEND_API_KEY=re_xxxxxxxxxxxxxxxxxxxx
  EMAIL_FROM="EduPortfolio <you@yourdomain.com>"

  NOTE: On Resend free tier you can only send from
  onboarding@resend.dev unless you verify your own domain.
  For testing, just leave EMAIL_FROM blank and it uses their default.


═══════════════════════════════════════════════
  ADMIN ACCOUNT SETUP
═══════════════════════════════════════════════

After running `npm run db:seed`, an admin account is created:
  Email:    admin@eduportfolio.com
  Password: Password123!

To make any existing user an admin, run in psql or Prisma Studio:
  UPDATE users SET role = 'ADMIN' WHERE email = 'your@email.com';

Or via Prisma Studio:
  npm run db:studio
  → Open users table → find your user → change role to ADMIN

Admin API endpoints (require Bearer token with ADMIN role):
  GET    /api/admin/users
  GET    /api/admin/stats
  PUT    /api/admin/users/:id
  POST   /api/admin/users/:id/suspend
  POST   /api/admin/users/:id/restore
  DELETE /api/admin/users/:id
  POST   /api/admin/users/:id/resend-otp
  POST   /api/admin/users/:id/verify
