// ─────────────────────────────────────────────
//  EduPortfolio Backend — Entry Point
// ─────────────────────────────────────────────
require('dotenv').config();
const express = require('express');
const helmet  = require('helmet');
const cors    = require('cors');

const authRoutes      = require('./routes/auth');
const portfolioRoutes = require('./routes/portfolio');
const { errorHandler } = require('./middleware/errorHandler');

const app  = express();
const PORT = process.env.PORT || 4000;

// ── SECURITY MIDDLEWARE ──
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── HEALTH CHECK ──
app.get('/health', (req, res) => {
  res.json({ status: 'ok', ts: new Date().toISOString() });
});

// ── ROUTES ──
app.use('/api/auth',      authRoutes);
app.use('/api/portfolio', portfolioRoutes);

// ── ERROR HANDLER ──
app.use(errorHandler);

// ── START ──
app.listen(PORT, () => {
  console.log(`\n✦ EduPortfolio API running on http://localhost:${PORT}`);
  console.log(`  Environment : ${process.env.NODE_ENV}`);
  console.log(`  Frontend    : ${process.env.FRONTEND_URL}\n`);
});
